# OSINT Intelligence

Локальная веб-платформа на FastAPI и SQLite. Интерфейс работает без CDN и сборки JavaScript. Поиск автоматически определяет тип объекта, запускает подходящие источники параллельно и формирует отчёт с доказательствами, ошибками, расхождениями, интерпретациями и графом связей. Доступны история, фильтры, статусы заданий, отмена и экспорт PDF, JSON и HTML.

## POCO X3 Pro · Android · Termux ARM64

Установите актуальный [Termux из F-Droid или официальных релизов](https://github.com/termux/termux-app#installation). Устанавливайте Termux и его дополнения из одного источника. В настройках Android для Termux выберите режим батареи без ограничений, если нужен длительный удалённый доступ. Android всё равно может остановить фоновый процесс при нехватке памяти.

Распакуйте ZIP в домашний каталог Termux, где доступны правильные разрешения файлов. Если архив лежит в Downloads, один раз выполните `termux-setup-storage`, разрешите доступ и выполните:

```bash
pkg install unzip
cd "$HOME"
unzip "$HOME/storage/downloads/osint-intelligence-web.zip"
cd osint-intelligence-web
bash setup-termux.sh
.venv/bin/python -m osint create-admin admin
.venv/bin/python -m osint serve
```

Откройте **http://127.0.0.1:8000** на телефоне и войдите с созданным паролем. Администратор создаёт аккаунты через вкладку «Администрирование». Один процесс обслуживает веб-интерфейс и задания. SQLite создаётся автоматически в `data/`. Устанавливать Docker, Redis, PostgreSQL и получать root-доступ не требуется.

Установка использует пакет Termux `python-pillow` и ограничивает Rust-сборку двумя потоками. `pydantic-core` и некоторые сетевые зависимости могут собираться из исходников, если для версии Python нет Android wheels. Держите Termux открытым до конца установки. Если устройство перегревается или сборка завершается из-за памяти, запустите `CARGO_BUILD_JOBS=1 bash setup-termux.sh`. После обновления системного Python до новой минорной версии пересоздайте виртуальное окружение. База и настройки хранятся отдельно. [Пакеты Termux](https://github.com/termux/termux-packages)

Для длительной работы можно использовать `termux-wake-lock` и две вкладки Termux для приложения и туннеля. Остановка приложения прерывает активные задания. Готовые отчёты сохраняются в SQLite. Для телефона по умолчанию включены два параллельных задания, максимум 5 MB на вложение и небольшой кеш в памяти. Файлы анализируются в памяти и не распаковываются.

## Linux и Windows

Нужен Python 3.12 или новее. Из корня проекта:

```bash
python -m venv .venv
source .venv/bin/activate
python -m pip install -r requirements.txt
cp .env.example .env
python -m osint create-admin admin
python -m osint serve
```

В PowerShell вместо `source` и `cp` используйте `.\.venv\Scripts\Activate.ps1` и `Copy-Item .env.example .env`. При ограничении выполнения скриптов вызывайте `.\.venv\Scripts\python.exe` вместо `python`. Для другого локального порта измените `WEB_ORIGIN` и передайте тот же порт через `serve --port`.

## Защищённый удалённый доступ через Cloudflare Tunnel

Нужны аккаунт Cloudflare и уже имеющийся домен в Cloudflare DNS. Локальный режим работает без них. Развёртывание ниже использует именованный туннель и Cloudflare Access. Сервер на телефоне слушает только loopback.

1. Установите `pkg install cloudflared`. Выполните `cloudflared tunnel login`, откройте полученную ссылку в браузере и выберите свой домен.
2. Выполните `cloudflared tunnel create osint`. Используйте выданный UUID в конфигурации. Выполните `cloudflared tunnel route dns osint osint.example.com`, заменив имя на своё.
3. В Zero Trust создайте приложение Access типа **Self-hosted** для полного поддомена. Добавьте политику **Allow** только для конкретных аккаунтов или группы вашего IdP. Скопируйте **Application Audience (AUD)** и имя команды.
4. Скопируйте `cloudflared.example.yml` в `~/.cloudflared/config.yml`. Замените UUID, путь к JSON, имя хоста, имя команды и AUD. Укажите в `.env` `WEB_ORIGIN=https://osint.example.com` без завершающего слеша. В HTTPS-режиме браузер отправляет сессионное cookie только по HTTPS.
5. В одном сеансе Termux выполните `.venv/bin/python -m osint serve`, в другом — `cloudflared tunnel --config "$HOME/.cloudflared/config.yml" ingress validate`, затем `cloudflared tunnel --config "$HOME/.cloudflared/config.yml" run osint`. Проверьте в приватной вкладке, что сначала открывается Cloudflare Access, а после разрешённого входа — форма платформы.

Ограничьте права на `.env`, конфиг и учётные файлы туннеля. Храните их в домашнем каталоге Termux. Для возврата к локальному режиму остановите туннель, восстановите HTTP loopback в `WEB_ORIGIN` и перезапустите приложение. [Именованный туннель](https://developers.cloudflare.com/tunnel/features/locally-managed-tunnels/create-local-tunnel/) · [Cloudflare Access](https://developers.cloudflare.com/cloudflare-one/access-controls/applications/http-apps/self-hosted-public-app/) · [Проверка JWT на стороне cloudflared](https://developers.cloudflare.com/tunnel/reference/origin-parameters/#access)

## Собственный цифровой след

- **GitHub.** Выберите «Мой GitHub», получите код и добавьте его как отдельное слово в Bio. Платформа читает через GitHub REST API публичную карточку, а платформа формирует результаты профиля только при совпадении кода. Удалите код после проверки.
- **Telegram и номер.** В BotFather настройте **Web Login**, зарегистрируйте свой HTTPS-адрес и callback `https://osint.example.com/auth/telegram`. Оставьте RS256, задайте `TELEGRAM_CLIENT_ID` и `TELEGRAM_CLIENT_SECRET`. На Termux установите `pkg install python-cryptography`, затем `.venv/bin/python -m pip install -r requirements-telegram.txt`. На ПК достаточно дополнительного файла требований. Секрет хранится на сервере. Веб-платформа проверяет state, PKCE, подпись JWT, issuer, audience и время действия. Номер запрашивается отдельным scope и попадает в модуль только из подтверждённого claim. Telegram-бот с polling не требуется. [Telegram Login](https://core.telegram.org/bots/telegram-login)
- **Email.** Полный адрес нужен только для синтаксической проверки. Отчёт и внешние DNS-запросы используют домен. Веб-платформа не проверяет владение почтовым ящиком и не выполняет поиск по адресу.
- **Согласие.** Владелец получает свой аккаунт в платформе и сам подтверждает GitHub или Telegram. Он может передать скачанный отчёт. Платформа не открывает отчёт другому аккаунту, включая администратора.
- **Вложения.** Загружайте файлы, которые имеете право исследовать. Метаданные GPS ограничены признаком наличия тега. Архивы не распаковываются. Для отдельного запроса SHA-256 включённая интеграция VirusTotal получает хеш.

## Источники

| Источник | Использование | Конфигурация |
|---|---|---|
| [Telegram Login](https://core.telegram.org/bots/telegram-login) | Владелец подтверждает доступ к собственному профилю или номеру через OIDC. Номер маскируется в отчёте | `TELEGRAM_CLIENT_ID`, `TELEGRAM_CLIENT_SECRET`, HTTPS и дополнительная зависимость |
| [Google Public DNS](https://developers.google.com/speed/public-dns/docs/doh/json) | A, AAAA, NS, CNAME, MX, TXT, DMARC | По умолчанию |
| [ICANN RDAP](https://www.icann.org/rdap), [IANA bootstrap](https://data.iana.org/rdap/dns.json) | Поиск регистрационных данных точного домена через сервер реестра. Сохраняются статус, даты и NS | По умолчанию |
| [RIPEstat](https://stat.ripe.net/docs/02.data-api/) | Публичный BGP-префикс, ASN и держатель AS | По умолчанию |
| [Certificate Transparency](https://certificate.transparency.dev/), [crt.sh](https://crt.sh/) | Наблюдавшиеся имена и записи сертификатов через публичный JSON-вывод crt.sh. Интерфейс может ограничивать запросы и не гарантирует полноту | `CT_ENABLED` |
| [SSLmate Certificate Search](https://sslmate.com/ct_search_api/) | Текущие выдачи из CT. Без ключа доступна ограниченная пробная квота. Для эксплуатации предусмотрен ключ | `CT_ENABLED`, `CERTSPOTTER_KEY` |
| [Wayback Availability API](https://archive.org/help/wayback_api.php) | Один доступный снимок адреса главной страницы | `WAYBACK_ENABLED` |
| [GitHub REST Users](https://docs.github.com/en/rest/users/users#get-a-user) | Проверка временного кода в Bio, затем логин, дата создания и число публичных репозиториев | `GITHUB_KEY` опционален |
| [Shodan REST](https://developer.shodan.io/api), [условия](https://static.shodan.io/legal/terms.html) | Публичное наблюдение об организации, ISP и приблизительном регионе. Возможности зависят от плана | `SHODAN_KEY` |
| [VirusTotal v3](https://docs.virustotal.com/reference/overview), [Public vs Premium](https://docs.virustotal.com/reference/public-vs-premium-api) | Чтение существующей репутации хеша, домена или IP. Для коммерческого использования подберите соответствующую лицензию. Публичный API ограничен условиями и квотами | `VIRUSTOTAL_KEY` |
| [urlscan.io](https://urlscan.io/docs/), [Search API](https://docs.urlscan.io/pages/search-api-reference) | Чтение существующих публичных наблюдений с указанным доменом. Учитывайте лимиты сервиса | `URLSCAN_KEY` |
| [AbuseIPDB](https://docs.abuseipdb.com/), [условия](https://www.abuseipdb.com/legal.html) | Чтение оценки и числа жалоб за 90 дней | `ABUSEIPDB_KEY` |
| [Companies House](https://developer.company-information.service.gov.uk/) | Поиск до шести совпадений в британском реестре | `COMPANIES_HOUSE_KEY` |
| [Brave Search](https://api-dashboard.search.brave.com/documentation/services/web-search) | До пяти ссылок для домена, по тарифу провайдера. Проверьте право сохранять результаты перед включением | `BRAVE_KEY` |
| [OpenAI Responses](https://platform.openai.com/docs/api-reference/responses/create) | Интерпретация технических фактов с привязкой к источнику | `OPENAI_KEY`, `OPENAI_MODEL` и включение в настройках пользователя |
| Сайт | Один запрос главной страницы, мета-теги, статус и список выбранных заголовков. Допускаются хосты, которые оператор явно авторизовал для проверки | `WEBSITE_HOSTS` |


Провайдеры с ключами опциональны. Админ-панель показывает только факт настройки ключа. Поля `error` и `status` в отчётах показывают ответ каждого источника. Метка «факт» относится к конкретному опубликованному наблюдению, а оценка репутации и совпадения отмечаются отдельно. Внешний анализ через OpenAI включается для конкретного запроса. Без ключа работает сводка наблюдений, ошибок и расхождений.

Прямой запрос главной страницы разрешён только для хостов из `WEBSITE_HOSTS`. Прямой HTTP-клиент запрещает частные и зарезервированные DNS-адреса и не следует редиректам. Сайт возвращает только метатеги и выбранные HTTP-заголовки. Документация [SpiderFoot](https://github.com/smicallef/spiderfoot), [OSINT Framework](https://github.com/lockfale/OSINT-Framework) и [ExifTool](https://exiftool.org/exiftool_pod.html) использовалась как справочная. Источники подключаются через `PLUGINS=package.module:source`, где экспортированный объект `Source` описывает поддерживаемые типы и async-функцию адаптера.

## Хранение и проверка

Пароли хешируются scrypt, идентификаторы сессий хранятся в виде SHA-256, cookie недоступно JavaScript. Проверяются заголовок Host и происхождение изменяющих запросов. Отчёты изолированы по владельцу, шифрование диска обеспечивает ОС. Для SQLite используйте резервное копирование при остановленном приложении или SQLite backup API. Предыдущая база Telegram-бота не импортируется автоматически. Выберите отдельный `DATABASE_PATH` и сохраните старую базу, если она нужна.

```bash
python -m pip install -r requirements-dev.txt
python -m pytest
ruff check .
```

Исходники интерфейса находятся в `osint/web/`, маршруты и фоновые задачи — в `osint/api.py`, хранение — в `osint/db.py`, адаптеры — в `osint/sources.py`. Сервер и источники `requirements.txt` проверяются в Linux; на телефоне скрипт использует диапазоны из `requirements.in`, чтобы выбрать совместимые с Termux пакеты.
