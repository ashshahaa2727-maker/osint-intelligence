import asyncio
import importlib
import json
from collections import defaultdict

import aiohttp

from .http import Client, Missing, Runtime, SourceError
from .models import Kind, Report, Result, Settings, Target
from .sources import SOURCES, Source, analyze


class Engine:
    def __init__(self, settings: Settings, runtime: Runtime):
        self.settings = settings
        self.runtime = runtime
        self.sources = list(SOURCES)
        for item in filter(None, map(str.strip, settings.plugins.split(","))):
            module, separator, attribute = item.partition(":")
            if not separator:
                raise ValueError("plugins require module:attribute")
            source = getattr(importlib.import_module(module), attribute)
            if not isinstance(source, Source) or any(s.name == source.name for s in self.sources):
                raise ValueError("invalid or duplicate source")
            self.sources.append(source)

    async def execute(self, name, operation=None):
        client = Client(self.runtime)
        if operation is None:
            return Result(module=name, status="disabled")
        try:
            async with asyncio.timeout(self.settings.timeout + 3):
                found = await operation(client)
        except Missing:
            return Result(module=name, status="empty", requests=client.requests, cache_hits=client.cache_hits)
        except SourceError as exc:
            status, message = "error", str(exc)
        except (TimeoutError, aiohttp.ClientError, OSError) as exc:
            status, message = "error", type(exc).__name__
        except Exception as exc:
            status, message = "error", f"unexpected source response ({type(exc).__name__})"
        else:
            return Result(
                module=name,
                status="ok" if found else "empty",
                findings=found,
                requests=client.requests,
                cache_hits=client.cache_hits,
            )
        return Result(
            module=name, status=status, error=message, requests=client.requests, cache_hits=client.cache_hits
        )

    async def investigate(self, target: Target, *, use_ai=False, language="ru", progress=None):
        required = {
            Kind.TELEGRAM: "telegram-oidc",
            Kind.PHONE: "telegram-oidc",
            Kind.USERNAME: "github-challenge",
            Kind.FILE: "web-upload",
            Kind.IMAGE: "web-upload",
            Kind.EMAIL: "domain-only",
        }
        if target.kind in required and target.authorization != required[target.kind]:
            raise ValueError("missing ownership proof")
        report = Report(kind=target.kind, subject=target.subject, authorization=target.authorization)
        selected = [source for source in self.sources if target.kind in source.kinds]

        async def execute(source):
            enabled = not source.flag or bool(getattr(self.settings, source.flag))
            operation = (lambda client: source.run(target, client, self.settings)) if enabled else None
            return await self.execute(source.name, operation)

        async with asyncio.TaskGroup() as jobs:
            tasks = [jobs.create_task(execute(source)) for source in selected]
            for task in asyncio.as_completed(tasks):
                result = await task
                report.modules.append(result)
                if progress:
                    await progress(result, len(report.modules), len(tasks) + 1)
        report.modules.sort(key=lambda result: result.module)
        self.aggregate(report)

        async def ai_operation(client):
            return await analyze(report, client, self.settings, language)

        enabled = self.settings.openai_key and use_ai and target.kind in {Kind.DOMAIN, Kind.WEBSITE, Kind.IP}
        analysis = await self.execute("ai_analysis", ai_operation if enabled else None)
        report.modules.append(analysis)
        report.findings.extend(analysis.findings)
        report.summary = {
            "facts": sum(item.classification == "fact" for item in report.findings),
            "possible": sum(item.classification == "possible" for item in report.findings),
            "conflicts": len(report.conflicts),
            "errors": [item.module for item in report.modules if item.status == "error"],
        }
        if progress:
            await progress(analysis, len(report.modules), len(report.modules))
        report.statistics = {
            "requests": sum(module.requests for module in report.modules),
            "cache_hits": sum(module.cache_hits for module in report.modules),
            **{
                status: sum(m.status == status for m in report.modules)
                for status in ("ok", "empty", "disabled", "error")
            },
        }
        report.recommendations = {
            Kind.EMAIL: ["email"],
            Kind.DOMAIN: ["dns"],
            Kind.WEBSITE: ["dns", "https"],
            Kind.IMAGE: ["exif"],
            Kind.FILE: ["files"],
            Kind.HASH: ["files"],
            Kind.IP: ["ip"],
            Kind.PHONE: ["mfa"],
            Kind.TELEGRAM: ["mfa"],
            Kind.USERNAME: ["mfa"],
        }.get(target.kind, ["company"])
        return report

    @staticmethod
    def aggregate(report):
        fingerprints = set()
        comparable = defaultdict(dict)
        edges = set()
        for module in report.modules:
            for finding in module.findings:
                value = json.dumps(finding.value, sort_keys=True, ensure_ascii=False)
                fingerprint = finding.key, value, finding.source
                if fingerprint in fingerprints:
                    continue
                fingerprints.add(fingerprint)
                report.findings.append(finding)
                if finding.key.startswith("dns.") and finding.classification == "fact":
                    comparable[finding.key][finding.source] = finding.value
                if finding.key.endswith((".1", ".28", ".5")) and finding.key.startswith("dns."):
                    relation = "dns_record"
                elif finding.key in {"rdap.nameservers", "ip.asn", "ct.names"}:
                    relation = finding.key
                else:
                    continue
                if isinstance(finding.value, list):
                    for node in finding.value[:100]:
                        edges.add((report.subject, relation, str(node), finding.source))
        ns_key = f"dns.{report.subject}.2"
        dns_ns = [item for item in report.findings if item.key == ns_key and isinstance(item.value, list)]
        registry_ns = [
            item
            for item in report.findings
            if item.key == "rdap.nameservers" and isinstance(item.value, list)
        ]
        for item in dns_ns + registry_ns:
            names = sorted({str(value).lower().rstrip(".") for value in item.value})
            comparable["nameserver_observation"][item.source] = names
        for label, by_source in comparable.items():
            if len({json.dumps(value, sort_keys=True) for value in by_source.values()}) > 1:
                report.conflicts.append({"key": label, "observations": by_source})
        report.edges = [
            {"from": left, "relation": rel, "to": right, "source": src}
            for left, rel, right, src in sorted(edges)
        ]
