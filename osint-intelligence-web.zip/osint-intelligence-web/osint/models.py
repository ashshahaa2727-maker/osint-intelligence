import ipaddress
import re
from datetime import UTC, datetime
from enum import StrEnum
from uuid import uuid4

from email_validator import EmailNotValidError, validate_email
from pydantic import BaseModel, Field, JsonValue, SecretStr
from pydantic_settings import BaseSettings, SettingsConfigDict
from yarl import URL


class Kind(StrEnum):
    DOMAIN = "domain"
    WEBSITE = "website"
    IP = "ip"
    EMAIL = "email"
    PHONE = "phone"
    USERNAME = "username"
    TELEGRAM = "telegram"
    COMPANY = "company"
    IMAGE = "image"
    FILE = "file"
    HASH = "hash"


class Settings(BaseSettings):
    model_config = SettingsConfigDict(env_file=".env", extra="ignore", env_ignore_empty=True)
    database_path: str = "data/osint.sqlite"
    web_origin: str = "http://127.0.0.1:8000"
    telegram_client_id: str = ""
    telegram_client_secret: SecretStr | None = None
    website_hosts: str = ""
    retention_days: int = Field(7, ge=1, le=90)
    file_bytes: int = Field(5_000_000, ge=1024, le=19_000_000)
    max_jobs: int = Field(2, ge=1, le=32)
    rate_seconds: int = Field(10, ge=1, le=3600)
    timeout: int = Field(20, ge=3, le=90)
    github_key: SecretStr | None = None
    shodan_key: SecretStr | None = None
    virustotal_key: SecretStr | None = None
    urlscan_key: SecretStr | None = None
    abuseipdb_key: SecretStr | None = None
    companies_house_key: SecretStr | None = None
    brave_key: SecretStr | None = None
    openai_key: SecretStr | None = None
    openai_model: str = "gpt-4.1-mini"
    ct_enabled: bool = True
    certspotter_key: SecretStr | None = None
    wayback_enabled: bool = True
    plugins: str = ""


class Target(BaseModel):
    kind: Kind
    value: str
    subject: str
    authorization: str = "operator"
    payload: bytes | None = Field(default=None, exclude=True)
    profile: dict[str, JsonValue] = Field(default_factory=dict, exclude=True)


class Finding(BaseModel):
    key: str
    value: JsonValue
    source: str
    confidence: str = "high"
    classification: str = "fact"


class Result(BaseModel):
    module: str
    status: str
    findings: list[Finding] = Field(default_factory=list)
    requests: int = 0
    cache_hits: int = 0
    error: str | None = None


class Report(BaseModel):
    id: str = Field(default_factory=lambda: uuid4().hex)
    created: datetime = Field(default_factory=lambda: datetime.now(UTC))
    kind: Kind
    subject: str
    authorization: str
    modules: list[Result] = Field(default_factory=list)
    findings: list[Finding] = Field(default_factory=list)
    conflicts: list[dict[str, JsonValue]] = Field(default_factory=list)
    edges: list[dict[str, str]] = Field(default_factory=list)
    summary: dict[str, JsonValue] = Field(default_factory=dict)
    statistics: dict[str, int] = Field(default_factory=dict)
    recommendations: list[str] = Field(default_factory=list)


def public_ip(value: str) -> bool:
    ip = ipaddress.ip_address(value)
    if isinstance(ip, ipaddress.IPv6Address) and (
        ip.ipv4_mapped
        or ip.sixtofour
        or ip.teredo
        or ip in ipaddress.ip_network("64:ff9b::/96")
        or ip in ipaddress.ip_network("64:ff9b:1::/48")
    ):
        return False
    return ip.is_global and not ip.is_multicast and not ip.is_reserved


def domain(value: str) -> str:
    text = value.rstrip(".").encode("idna").decode().lower()
    if len(text) > 253 or not re.fullmatch(
        r"(?:[a-z0-9](?:[a-z0-9-]{0,61}[a-z0-9])?\.)+[a-z](?:[a-z0-9-]{0,61}[a-z0-9])?", text
    ):
        raise ValueError("invalid domain")
    if text.rsplit(".", 1)[-1] in {
        "localhost",
        "local",
        "internal",
        "onion",
        "test",
        "invalid",
        "example",
        "alt",
    }:
        raise ValueError("non-public domain")
    if text.endswith(".home.arpa"):
        raise ValueError("non-public domain")
    return text


def parse(raw: str, forced: Kind | None = None) -> Target:
    raw = raw.strip()
    if not raw or len(raw) > 512 or any(ord(c) < 32 for c in raw):
        raise ValueError("invalid input")
    if forced == Kind.COMPANY or (forced is None and raw.lower().startswith("company:")):
        name = raw.split(":", 1)[1].strip() if raw.lower().startswith("company:") else raw
        if not name or len(name) > 120 or "@" in name:
            raise ValueError("invalid company")
        return Target(kind=Kind.COMPANY, value=name, subject=name)
    if forced in (None, Kind.WEBSITE) and raw.lower().startswith(("http://", "https://")):
        url = URL(raw)
        if (
            url.user is not None
            or url.password is not None
            or url.port != (443 if url.scheme == "https" else 80)
        ):
            raise ValueError("invalid URL")
        host = domain(url.host or "")
        return Target(kind=Kind.WEBSITE, value=f"{url.scheme}://{host}/", subject=host)
    if forced in (None, Kind.EMAIL) and "@" in raw and not raw.startswith("@"):
        try:
            address = validate_email(raw, check_deliverability=False)
        except EmailNotValidError as exc:
            raise ValueError("invalid email") from exc
        host = domain(address.ascii_domain)
        return Target(kind=Kind.EMAIL, value=host, subject=host, authorization="domain-only")
    if forced in (None, Kind.HASH) and re.fullmatch(r"[a-fA-F0-9]{64}", raw):
        return Target(kind=Kind.HASH, value=raw.lower(), subject=raw.lower())
    if forced in (None, Kind.IP) and "%" not in raw:
        try:
            ip = ipaddress.ip_address(raw)
        except ValueError:
            pass
        else:
            if not public_ip(str(ip)):
                raise ValueError("non-public IP")
            return Target(kind=Kind.IP, value=str(ip), subject=str(ip))
    if forced in (None, Kind.DOMAIN):
        host = domain(raw)
        return Target(kind=Kind.DOMAIN, value=host, subject=host)
    raise ValueError("unsupported input")
