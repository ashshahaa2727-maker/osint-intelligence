import csv
import html
import io
import json
import unicodedata
from pathlib import Path

from fontTools.ttLib import TTFont
from fpdf import FPDF
from fpdf.enums import WrapMode

from .locale import text

FONT = Path(__file__).parent / "assets" / "DejaVuSans.ttf"


def display(value):
    return value if isinstance(value, str) else json.dumps(value, ensure_ascii=False, sort_keys=True)


def rows(report, locale):
    for label in ("id", "created", "kind", "subject", "authorization", "statistics", "summary"):
        yield (
            "report",
            label,
            display(report.created.isoformat() if label == "created" else getattr(report, label)),
            "",
            "",
            "",
        )
    for module in report.modules:
        yield (
            "module",
            module.module,
            display(
                {
                    "status": module.status,
                    "requests": module.requests,
                    "cache_hits": module.cache_hits,
                    "findings": len(module.findings),
                    "error": module.error,
                }
            ),
            "",
            "",
            "",
        )
        for item in module.findings:
            yield (
                module.module,
                item.key,
                display(item.value),
                item.classification,
                item.confidence,
                item.source,
            )
    for conflict in report.conflicts:
        yield ("conflict", conflict["key"], display(conflict["observations"]), "", "", "")
    for edge in report.edges:
        yield ("graph", edge["relation"], f"{edge['from']} → {edge['to']}", "", "", edge["source"])
    for recommendation in report.recommendations:
        yield ("recommendation", recommendation, text(locale, "rec_" + recommendation), "", "", "")


def export(report, fmt, locale):
    if fmt == "json":
        data = report.model_dump(mode="json")
        data["recommendation_text"] = [text(locale, "rec_" + item) for item in report.recommendations]
        return json.dumps(data, ensure_ascii=False, indent=2).encode()
    entries = list(rows(report, locale))
    if fmt == "csv":
        out = io.StringIO(newline="")
        writer = csv.writer(out)
        writer.writerow(["section", "field", "value", "classification", "confidence", "source"])
        for row in entries:
            writer.writerow(
                [
                    "'" + cell
                    if cell.lstrip().startswith(("=", "+", "-", "@")) or cell.startswith(("\t", "\r", "\n"))
                    else cell
                    for cell in row
                ]
            )
        return out.getvalue().encode("utf-8-sig")
    if fmt == "html":
        head = (
            "<!doctype html><html><head><meta charset=utf-8>"
            "<meta name=viewport content='width=device-width,initial-scale=1'>"
            "<meta http-equiv=Content-Security-Policy content=\"default-src 'none'; style-src 'unsafe-inline'\">"
            "<title>OSINT</title><style>body{font:16px system-ui;max-width:1000px;margin:2rem auto;padding:1rem}"
            "section{border-bottom:1px solid #ccc;padding:.8rem;overflow-wrap:anywhere}small{display:block}</style>"
            "</head><body><h1>OSINT Intelligence Bot</h1>"
        )
        sections = []
        for section, label, value, classification, confidence, source in entries:
            source_text = html.escape(source, quote=True)
            if source.startswith(("https://", "http://")):
                source_text = f'<a rel="noreferrer noopener" href="{source_text}">{source_text}</a>'
            sections.append(
                f"<section><b>{html.escape(section + ' / ' + label)}</b><div>{html.escape(value)}</div>"
                f"<small>{html.escape(classification + ' ' + confidence)} {source_text}</small></section>"
            )
        return (head + "".join(sections) + "</body></html>").encode()
    content = "\n\n".join(" | ".join(filter(None, row)) for row in entries)
    if fmt == "txt":
        return content.encode()
    if fmt != "pdf":
        raise ValueError("unsupported export")
    with TTFont(FONT) as font:
        supported = font.getBestCmap()
    pdf = FPDF()
    pdf.add_page()
    pdf.add_font("DejaVu", fname=str(FONT))
    pdf.set_font("DejaVu", size=10)
    content = "".join(
        char
        if char == "\n" or ord(char) in supported
        else ("" if unicodedata.category(char) == "Cf" else "�")
        for char in content
    )
    pdf.multi_cell(0, 5, content, wrapmode=WrapMode.CHAR)
    return bytes(pdf.output())
