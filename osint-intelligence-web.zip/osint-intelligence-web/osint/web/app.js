const $ = (id) => document.getElementById(id);
const pages = ["search", "history", "report", "admin"];
const kinds = {domain:"Домен", website:"Веб-сайт", ip:"IP-адрес", email:"Email", phone:"Телефон",
  username:"GitHub", telegram:"Telegram", company:"Организация", file:"Файл", image:"Изображение", hash:"SHA-256"};
const statuses = {ok:"готово", empty:"нет данных", disabled:"отключён", error:"ошибка"};
const confidence = {high:"Высокая", medium:"Средняя", low:"Низкая"};
const classes = {fact:"Факт", possible:"Возможное совпадение", analysis:"Интерпретация"};
const recommendations = {
  email:"Проверьте SPF и DMARC своего домена. Включите MFA для почты.",
  dns:"Сверьте DNS и имена из сертификатов со своим инвентарём.",
  https:"Проверьте HTTPS и заголовки безопасности на своём сайте.",
  exif:"Проверьте наличие метаданных геолокации перед публикацией фотографии.",
  files:"Сверьте SHA-256 с доверенным источником.",
  ip:"Сверьте сведения об адресе с инвентарём и учтите дату наблюдения.",
  mfa:"Включите MFA и проверьте активные сеансы.",
  company:"Сверьте номер компании и юрисдикцию.",
};
let account = null;
let activeJob = null;
let jobTimer = null;
let currentReport = null;
let noticeTimer = null;
let viewVersion = 0;

function element(tag, content, className) {
  const item = document.createElement(tag);
  if (content !== undefined) item.textContent = content;
  if (className) item.className = className;
  return item;
}
function link(url, title) {
  const item = element("a", title || url);
  try {
    const source = new URL(url);
    if (["http:", "https:"].includes(source.protocol) && !source.username && !source.password) {
      item.href = source.href;
      item.rel = "noreferrer noopener";
      item.target = "_blank";
    }
  } catch { /* Source labels can be plain text. */ }
  return item;
}
function notify(message) {
  clearTimeout(noticeTimer);
  $("notice").textContent = message;
  $("notice").hidden = false;
  noticeTimer = setTimeout(() => { $("notice").hidden = true; }, 5500);
}
async function api(path, options = {}) {
  const headers = new Headers(options.headers);
  if (options.method && options.method !== "GET") headers.set("X-OSINT", "1");
  if (options.json) headers.set("Content-Type", "application/json");
  const response = await fetch(path, {...options, headers, body: options.json ? JSON.stringify(options.json) : options.body});
  if (response.status === 401 && path !== "/api/login") showLogin();
  if (!response.ok) {
    let message;
    try { message = (await response.json()).detail; } catch { message = null; }
    throw new Error(typeof message === "string" ? message : "Операция не выполнена");
  }
  return response.status === 204 ? null : response.json();
}
function showLogin() {
  viewVersion++;
  clearTimeout(jobTimer);
  activeJob = currentReport = account = null;
  $("login").hidden = false;
  $("app").hidden = true;
  $("challenge").textContent = "";
  $("progress").hidden = true;
  $("notice").hidden = true;
  for (const id of ["history-list", "findings", "accounts", "sources", "edges", "modules", "providers", "exports", "conflicts", "recommendations"]) {
    $(id).replaceChildren();
  }
  for (const id of ["search-form", "upload", "filters", "add-account", "login-form"]) $(id).reset();
}
function page(name) {
  for (const id of pages) $(id).hidden = name !== id;
  for (const button of document.querySelectorAll("[data-page]")) {
    if (button.dataset.page === name || (name === "report" && button.dataset.page === "history")) {
      button.setAttribute("aria-current", "page");
    } else button.removeAttribute("aria-current");
  }
  if (name === "history") loadHistory().catch((error) => notify(error.message));
  if (name === "admin") loadAdmin().catch((error) => notify(error.message));
}
async function enter() {
  account = await api("/api/me");
  $("login").hidden = true;
  $("app").hidden = false;
  $("username").textContent = account.username;
  $("admin-nav").hidden = !account.admin;
  $("ai-label").hidden = !account.ai;
  $("telegram-note").textContent = account.telegram ? "Подтвердите профиль или номер через Telegram." : "Подключается через Telegram Login по HTTPS.";
  for (const button of document.querySelectorAll("[data-telegram]")) button.disabled = !account.telegram;
  $("retention").textContent = `Срок доступности отчётов — ${account.retention} дн.`;
  page("search");
  const hash = location.hash;
  if (hash) {
    history.replaceState(null, "", location.pathname);
    if (/^#job=[a-f0-9]{32}$/.test(hash)) watch(hash.slice(5));
    if (hash === "#telegram-error") notify("Подтверждение Telegram не завершено.");
  }
}
function data(form) { return Object.fromEntries(new FormData(form)); }
$("login-form").addEventListener("submit", async (event) => {
  event.preventDefault();
  const button = event.submitter;
  button.disabled = true;
  $("login-error").textContent = "";
  try {
    await api("/api/login", {method:"POST", json:data(event.currentTarget)});
    event.target.reset();
    await enter();
  } catch (error) { $("login-error").textContent = error.message; }
  finally { button.disabled = false; }
});
$("logout").addEventListener("click", async () => {
  try { await api("/api/logout", {method:"POST"}); showLogin(); }
  catch (error) { notify(error.message); }
});
document.querySelectorAll("[data-page]").forEach((button) => button.addEventListener("click", () => page(button.dataset.page)));
$("back").addEventListener("click", () => page("history"));
const hints = {
  auto:"Email проверяется по DNS домена. Для названия компании используйте префикс company:.",
  domain:"DNS, RDAP, сертификаты и доступные наблюдения.",
  website:"Сведения о корневой странице и заголовки для разрешённых оператором хостов.",
  ip:"Публичный IP-адрес. Маршрутизация и доступные репутационные оценки.",
  email:"Полный адрес используется для проверки синтаксиса. В отчёте остаётся домен.",
  hash:"64 шестнадцатеричных символа. При включённом VirusTotal хеш передаётся сервису.",
  company:"Введите название организации из британского реестра Companies House.",
  username:"Подтвердите контроль профиля одноразовым кодом.",
};
function modeChanged() {
  const mode = $("mode").value;
  $("mode-hint").textContent = hints[mode];
  $("github-actions").hidden = mode !== "username";
  $("target").placeholder = ({username:"Логин GitHub",company:"Название компании",email:"name@example.com"})[mode]
    || "Домен, публичный IP, URL или SHA-256";
}
$("mode").addEventListener("change", modeChanged);
modeChanged();
$("github").addEventListener("click", async () => {
  try {
    const result = await api("/api/github", {method:"POST"});
    $("challenge").textContent = `Добавьте ${result.challenge} отдельным словом в Bio своего GitHub и отправьте логин. Код действует 10 минут и используется один раз.`;
  } catch (error) { notify(error.message); }
});
async function launch(button, request) {
  button.disabled = true;
  try { watch((await request()).job); }
  catch (error) { notify(error.message); }
  finally { button.disabled = false; }
}
$("search-form").addEventListener("submit", (event) => {
  event.preventDefault();
  const form = data(event.currentTarget);
  form.ai = $("ai").checked;
  launch(event.submitter, () => api("/api/studies", {method:"POST", json:form}));
});
$("upload").addEventListener("submit", (event) => {
  event.preventDefault();
  const file = $("file").files[0];
  if (!file || !file.size || file.size > account.file_bytes) {
    notify(`Допустимый размер — от 1 байта до ${account.file_bytes.toLocaleString("ru")} байт.`);
    return;
  }
  launch(event.submitter, () => api("/api/upload/" + event.submitter.value,
    {method:"POST", headers:{"Content-Type":"application/octet-stream"}, body:file}));
});
for (const button of document.querySelectorAll("[data-telegram]")) {
  button.addEventListener("click", async () => {
    button.disabled = true;
    try {
      const result = await api("/api/telegram/" + button.dataset.telegram, {method:"POST"});
      const destination = new URL(result.url);
      if (destination.origin !== "https://oauth.telegram.org") throw new Error("Ошибочный адрес Telegram.");
      location.assign(destination.href);
    } catch (error) { notify(error.message); button.disabled = false; }
  });
}
function moduleRow(name, status, error) {
  const item = element("li", `${name} · ${statuses[status] || status}${error ? " · " + error : ""}`);
  item.dataset.status = status;
  return item;
}
function watch(identifier) {
  clearTimeout(jobTimer);
  activeJob = identifier;
  $("progress").hidden = false;
  $("cancel").hidden = false;
  $("job-state").textContent = "Выполняется исследование";
  $("bar").removeAttribute("value");
  $("modules").replaceChildren();
  page("search");
  async function poll() {
    if (activeJob !== identifier) return;
    try {
      const result = await api("/api/jobs/" + identifier);
      if (activeJob !== identifier) return;
      $("modules").replaceChildren(...result.modules.map((row) => moduleRow(row.name, row.status)));
      if (result.total) { $("bar").max = result.total; $("bar").value = result.modules.length; }
      if (result.status === "running") { jobTimer = setTimeout(poll, 1000); return; }
      activeJob = null;
      $("cancel").hidden = true;
      const labels = {done:"Исследование завершено", cancelled:"Исследование отменено", failed:"Исследование завершилось ошибкой"};
      $("job-state").textContent = labels[result.status] || result.status;
      if (result.report) await showReport(result.report);
    } catch (error) {
      activeJob = null;
      $("cancel").hidden = true;
      $("job-state").textContent = "Статус недоступен";
      notify(error.message);
    }
  }
  poll();
}
$("cancel").addEventListener("click", async () => {
  if (!activeJob) return;
  try { await api("/api/jobs/" + activeJob, {method:"DELETE"}); }
  catch (error) { notify(error.message); }
});
for (const [kind, label] of Object.entries(kinds)) {
  const option = element("option", label);
  option.value = kind;
  $("filter-kind").append(option);
}
$("filters").addEventListener("submit", (event) => {
  event.preventDefault();
  loadHistory().catch((error) => notify(error.message));
});
const time = (date) => new Intl.DateTimeFormat("ru", {dateStyle:"medium", timeStyle:"short"}).format(new Date(date));
async function loadHistory() {
  const version = viewVersion;
  const reports = await api("/api/studies?" + new URLSearchParams(data($("filters"))));
  if (version !== viewVersion) return;
  $("history-list").replaceChildren(...(reports.length ? reports.map((report) => {
    const row = element("li");
    const button = element("button", report.subject, "quiet history-button");
    button.addEventListener("click", () => showReport(report.id).catch((error) => notify(error.message)));
    row.append(button, element("small", `${kinds[report.kind] || report.kind} · ${time(report.created)}`, "muted"));
    return row;
  }) : [element("li", "Исследований пока нет.", "muted")]));
}
const display = (value) => typeof value === "string" ? value : JSON.stringify(value, null, 2);
function renderFindings() {
  if (!currentReport) return;
  const filter = $("classification").value;
  const findings = currentReport.findings.filter((item) => !filter || item.classification === filter);
  $("findings").replaceChildren(...(findings.length ? findings.map((finding) => {
    const row = element("li");
    const chip = element("span", `${classes[finding.classification] || finding.classification} · ${confidence[finding.confidence] || finding.confidence}`, "chip");
    chip.dataset.kind = finding.classification;
    const source = link(finding.source);
    source.className = "mono";
    row.append(element("strong", finding.key, "mono"), document.createTextNode(" "), chip, element("p", display(finding.value)), source);
    return row;
  }) : [element("li", "Наблюдений нет.", "muted")]));
}
$("classification").addEventListener("change", renderFindings);
function drawGraph() {
  if (!currentReport || $("report").hidden || $("graph").hidden) return;
  const canvas = $("graph");
  const ctx = canvas.getContext("2d");
  if (!ctx) return;
  const width = Math.floor(canvas.clientWidth);
  const height = Math.floor(canvas.clientHeight);
  const density = Math.min(2, devicePixelRatio || 1);
  canvas.width = width * density;
  canvas.height = height * density;
  ctx.scale(density, density);
  const center = [width / 2, height / 2];
  const nodes = [...new Set(currentReport.edges.map((edge) => edge.to))].slice(0, 12);
  const points = nodes.map((name, index) => {
    const angle = (index / nodes.length) * Math.PI * 2 - Math.PI / 2;
    return {name, x:center[0] + (width * .32) * Math.cos(angle), y:center[1] + (height * .36) * Math.sin(angle)};
  });
  ctx.strokeStyle = "#426d56";
  for (const point of points) {
    ctx.beginPath();
    ctx.moveTo(...center);
    ctx.lineTo(point.x, point.y);
    ctx.stroke();
  }
  ctx.textAlign = "center";
  ctx.font = "11px system-ui";
  for (const point of [...points, {x:center[0], y:center[1], name:currentReport.subject}]) {
    ctx.beginPath();
    ctx.arc(point.x, point.y, 4.5, 0, 2 * Math.PI);
    ctx.fillStyle = "#74edaf";
    ctx.fill();
    ctx.fillStyle = "#d4ebdc";
    const labelWidth = Math.min(100, width * .29);
    let name = point.name;
    while (name.length > 4 && ctx.measureText(name).width > labelWidth) name = name.slice(0, -2) + "…";
    ctx.fillText(name, point.x, point.y + 16, labelWidth);
  }
}
new ResizeObserver(drawGraph).observe($("graph"));
async function showReport(identifier) {
  const version = viewVersion;
  const report = await api("/api/studies/" + identifier);
  if (version !== viewVersion || !account) return;
  currentReport = report;
  $("subject").textContent = report.subject;
  $("report-meta").textContent = `${kinds[report.kind] || report.kind} · ${time(report.created)} · ${report.id}`;
  $("exports").replaceChildren(...["pdf", "json", "html"].map((format) => {
    const action = element("a", format.toUpperCase(), "export");
    action.href = `/api/studies/${report.id}/export/${format}`;
    return action;
  }));
  const stats = [[report.summary.facts, "Фактов"], [report.summary.possible, "Совпадений"], [report.statistics.requests, "Запросов"], [report.statistics.error, "Ошибок"]];
  $("statistics").replaceChildren(...stats.map(([value, label]) => {
    const cell = element("div", undefined, "stat");
    cell.append(element("b", value ?? 0), document.createTextNode(label));
    return cell;
  }));
  $("sources").replaceChildren(...report.modules.map((item) => moduleRow(item.module, item.status, item.error)));
  $("graph").hidden = !report.edges.length;
  $("edges").replaceChildren(...(report.edges.length ? report.edges.map((edge) => {
    const row = element("li");
    row.append(link(edge.source, `${edge.from} → ${edge.to}`), document.createTextNode(" · " + edge.relation));
    return row;
  }) : [element("li", "Связи не обнаружены.")]));
  $("conflicts").replaceChildren(...(report.conflicts.length ?
    report.conflicts.map((item) => element("li", item.key + " · " + display(item.observations))) :
    [element("li", "Расхождения не обнаружены.", "muted")]));
  $("recommendations").replaceChildren(...report.recommendations.map((item) => element("li", recommendations[item] || item)));
  $("classification").value = "";
  renderFindings();
  page("report");
  drawGraph();
  window.scrollTo(0, 0);
}
$("delete").addEventListener("click", async () => {
  if (!currentReport || !window.confirm("Удалить этот отчёт?")) return;
  try {
    await api("/api/studies/" + currentReport.id, {method:"DELETE"});
    currentReport = null;
    page("history");
    notify("Отчёт удалён.");
  } catch (error) { notify(error.message); }
});
async function loadAdmin() {
  const version = viewVersion;
  const result = await api("/api/admin");
  if (version !== viewVersion) return;
  $("admin-status").textContent = `Активные задания: ${result.active}`;
  $("accounts").replaceChildren(...result.accounts.map((item) => {
    const row = element("li");
    row.append(element("span", item.username + (item.admin ? " · администратор" : "")));
    if (!item.admin) {
      const button = element("button", item.enabled ? "Отключить" : "Включить", "secondary");
      button.addEventListener("click", async () => {
        button.disabled = true;
        try {
          await api("/api/admin/accounts/" + item.id, {method:"PATCH", json:{enabled:!item.enabled}});
          await loadAdmin();
        } catch (error) { notify(error.message); button.disabled = false; }
      });
      row.append(button);
    }
    return row;
  }));
  $("providers").replaceChildren(...Object.entries(result.providers).map(([name, enabled]) => moduleRow(name, enabled ? "ok" : "disabled")));
}
$("add-account").addEventListener("submit", async (event) => {
  event.preventDefault();
  const form = event.currentTarget;
  try {
    await api("/api/admin/accounts", {method:"POST", json:data(form)});
    form.reset();
    await loadAdmin();
    notify("Аккаунт создан.");
  } catch (error) { notify(error.message); }
});
enter().catch(() => {});
