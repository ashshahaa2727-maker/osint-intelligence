STRINGS = {
    "smart": ("🔎 Умный поиск", "🔎 Smart lookup", "🔎 Aqlli qidiruv"),
    "domain": ("🌐 Поиск по домену", "🌐 Domain lookup", "🌐 Domen qidiruvi"),
    "phone": ("📱 Аудит номера", "📱 Phone audit", "📱 Raqam auditi"),
    "email": ("📧 Аудит Email", "📧 Email audit", "📧 Email auditi"),
    "foot": ("👤 Мой цифровой след", "👤 My digital footprint", "👤 Raqamli izim"),
    "image": ("🖼 Анализ изображения", "🖼 Image analysis", "🖼 Rasm tahlili"),
    "file": ("📂 Анализ файла", "📂 File analysis", "📂 Fayl tahlili"),
    "threat": ("🛡 Киберразведка", "🛡 Threat intelligence", "🛡 Kiberrazvedka"),
    "company": ("🏢 Поиск организации", "🏢 Company lookup", "🏢 Tashkilot qidiruvi"),
    "report": ("📊 Полный отчёт", "📊 Full report", "📊 To‘liq hisobot"),
    "history": ("📁 История запросов", "📁 History", "📁 So‘rovlar tarixi"),
    "settings": ("⚙️ Настройки", "⚙️ Settings", "⚙️ Sozlamalar"),
    "menu": ("Выберите действие.", "Choose an action.", "Amalni tanlang."),
    "smart_hint": (
        "Введите домен, URL, публичный IP или SHA‑256. Для компании начните с company:.",
        "Enter a domain, URL, public IP or SHA-256. Prefix company names with company:.",
        "Domen, URL, ochiq IP yoki SHA‑256 kiriting. Tashkilot uchun company: prefiksidan foydalaning.",
    ),
    "domain_hint": (
        "Введите полное доменное имя.",
        "Enter a full domain name.",
        "To‘liq domen nomini kiriting.",
    ),
    "email_hint": (
        "Введите свой Email. Удалите сообщение с адресом после проверки. Отчёт хранит только домен.",
        "Enter your email. Delete the message containing it after the audit. Only the domain goes in the report.",
        "Emailingizni kiriting. Tekshiruvdan keyin manzilli xabarni o‘chiring. Hisobotda faqat domen saqlanadi.",
    ),
    "threat_hint": (
        "Введите домен, публичный IP или SHA‑256. Хеш передаётся VirusTotal, если интеграция включена.",
        "Enter a domain, public IP or SHA-256. If enabled, VirusTotal receives the hash.",
        "Domen, ochiq IP yoki SHA‑256 kiriting. VirusTotal yoqilgan bo‘lsa, xesh yuboriladi.",
    ),
    "company_hint": (
        "Введите название британской компании.",
        "Enter a UK company name.",
        "Britaniya kompaniyasi nomini kiriting.",
    ),
    "file_hint": (
        "Пришлите свой файл. В отчёте сохранится хеш, размер и предполагаемый тип.",
        "Send your file. The report retains its hash, size and detected type.",
        "Faylingizni yuboring. Hisobotda xesh, hajm va aniqlangan turi saqlanadi.",
    ),
    "image_hint": (
        "Пришлите JPEG, PNG или WebP документом, чтобы сохранить метаданные оригинала.",
        "Send JPEG, PNG or WebP as a document to preserve original metadata.",
        "Asl metama’lumotlar uchun JPEG, PNG yoki WebP formatini hujjat qilib yuboring.",
    ),
    "share_phone": ("Поделиться своим номером", "Share my number", "Raqamimni ulashish"),
    "phone_hint": (
        "Отправьте свой контакт кнопкой Telegram.",
        "Use Telegram’s button to share your own contact.",
        "Telegram tugmasi yordamida o‘z kontaktingizni yuboring.",
    ),
    "github_hint": (
        "Добавьте код {code} отдельным словом в Bio своего GitHub, затем пришлите логин. Код действует 10 минут.",
        "Add {code} as a separate word to your GitHub bio, then send your login. It expires in 10 minutes.",
        "{code} kodini GitHub Bio bo‘limiga alohida so‘z sifatida qo‘shing, keyin loginni yuboring. Kod 10 daqiqa amal qiladi.",
    ),
    "denied": (
        "Доступ закрыт. Ваш Telegram ID: {id}",
        "Access restricted. Your Telegram ID: {id}",
        "Kirish cheklangan. Telegram ID: {id}",
    ),
    "bad": (
        "Ввод не подходит для выбранного действия.",
        "Input is invalid for this action.",
        "Kiritilgan ma’lumot bu amalga mos emas.",
    ),
    "busy": (
        "Подождите перед новым запросом.",
        "Wait before starting another request.",
        "Yangi so‘rovdan oldin kuting.",
    ),
    "cancel": ("Отменить", "Cancel", "Bekor qilish"),
    "cancelled": ("Исследование отменено.", "Investigation cancelled.", "Tadqiqot bekor qilindi."),
    "active": ("Исследование выполняется…", "Investigation in progress…", "Tadqiqot davom etmoqda…"),
    "failed": ("Не удалось завершить операцию.", "The operation failed.", "Amal bajarilmadi."),
    "done": (
        "Отчёт {id} готов. Запросы: {n}. Ошибки: {errors}.",
        "Report {id} ready. Requests: {n}. Errors: {errors}.",
        "{id} hisoboti tayyor. So‘rovlar: {n}. Xatolar: {errors}.",
    ),
    "missing": ("Доступных отчётов нет.", "No reports available.", "Hisobotlar mavjud emas."),
    "formats": ("Выберите формат экспорта.", "Choose an export format.", "Eksport formatini tanlang."),
    "delete": ("Удалить отчёт", "Delete report", "Hisobotni o‘chirish"),
    "delete_all": ("Удалить все отчёты", "Delete all reports", "Barcha hisobotlarni o‘chirish"),
    "confirm": ("Подтвердите удаление.", "Confirm deletion.", "O‘chirishni tasdiqlang."),
    "deleted": ("Удалено отчётов: {n}.", "Deleted reports: {n}.", "O‘chirilgan hisobotlar: {n}."),
    "days": (
        "Хранение новых отчётов: {days} дн.",
        "New reports retained for {days} days.",
        "Yangi hisobotlar {days} kun saqlanadi.",
    ),
    "ai": (
        "ИИ для технических отчётов: {status}. При включении OpenAI получает технические факты.",
        "Technical AI analysis: {status}. When enabled, OpenAI receives technical findings.",
        "Texnik AI tahlili: {status}. Yoqilganda OpenAI texnik ma’lumotlarni oladi.",
    ),
    "on": ("включён", "on", "yoqilgan"),
    "off": ("выключен", "off", "o‘chirilgan"),
    "unavailable": ("недоступен", "unavailable", "mavjud emas"),
    "ok": ("готово", "complete", "tayyor"),
    "empty": ("нет данных", "no data", "ma’lumot yo‘q"),
    "disabled": ("отключён", "disabled", "o‘chirilgan"),
    "error": ("ошибка", "error", "xato"),
    "rec_email": (
        "Проверьте SPF и DMARC своего домена. Включите MFA для почтового аккаунта.",
        "Review your domain’s SPF and DMARC. Enable MFA for your mail account.",
        "Domeningiz SPF va DMARC sozlamalarini tekshiring. Email hisobida MFA yoqing.",
    ),
    "rec_dns": (
        "Сверьте DNS и имена из сертификатов со своим инвентарём.",
        "Compare DNS and certificate names with your inventory.",
        "DNS va sertifikat nomlarini inventar bilan tekshiring.",
    ),
    "rec_https": (
        "Проверьте HTTPS и заголовки безопасности на своём сайте.",
        "Review HTTPS and security headers on your site.",
        "Saytingiz HTTPS va xavfsizlik sarlavhalarini tekshiring.",
    ),
    "rec_exif": (
        "Перед публикацией фото проверьте теги геолокации.",
        "Review location tags before sharing photos.",
        "Rasm ulashishdan oldin joylashuv teglarini tekshiring.",
    ),
    "rec_files": (
        "Сверяйте SHA-256 с доверенным источником.",
        "Compare SHA-256 against a trusted source.",
        "SHA-256 ni ishonchli manba bilan solishtiring.",
    ),
    "rec_ip": (
        "Сверьте сведения об адресе с инвентарём и учтите дату наблюдения.",
        "Compare address data with inventory and check observation dates.",
        "Manzil ma’lumotlarini inventar bilan solishtiring va kuzatuv sanasini tekshiring.",
    ),
    "rec_mfa": (
        "Включите MFA и проверьте активные сеансы.",
        "Enable MFA and review active sessions.",
        "MFA yoqing va faol seanslarni tekshiring.",
    ),
    "rec_company": (
        "Сверьте номер компании и юрисдикцию.",
        "Verify the company number and jurisdiction.",
        "Tashkilot raqami va yurisdiksiyasini tekshiring.",
    ),
    "admin": (
        "Активных заданий: {jobs}. Доступных отчётов: {reports}.",
        "Active jobs: {jobs}. Available reports: {reports}.",
        "Faol vazifalar: {jobs}. Mavjud hisobotlar: {reports}.",
    ),
}

LANGUAGES = {"ru": "Russian", "en": "English", "uz": "Uzbek"}


def text(locale, name, **values):
    return STRINGS[name][{"ru": 0, "en": 1, "uz": 2}.get(locale, 0)].format(**values)
