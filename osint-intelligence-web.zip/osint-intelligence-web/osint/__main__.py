import argparse
import getpass
import sqlite3

import uvicorn

from .db import Store
from .models import Settings


def main():
    parser = argparse.ArgumentParser(description="OSINT Intelligence")
    commands = parser.add_subparsers(dest="command")
    run = commands.add_parser("serve")
    run.add_argument("--port", type=int, default=8000)
    admin = commands.add_parser("create-admin")
    admin.add_argument("username")
    args = parser.parse_args()
    if args.command == "create-admin":
        settings = Settings()
        password = getpass.getpass("Пароль администратора: ")
        if password != getpass.getpass("Повторите пароль: "):
            parser.error("Пароли различаются")
        try:
            Store(settings.database_path, settings.retention_days).create(args.username, password, admin=True)
        except (ValueError, sqlite3.IntegrityError) as exc:
            parser.error(str(exc))
        print("Администратор создан")
    else:
        uvicorn.run(
            "osint.api:create_app",
            factory=True,
            host="127.0.0.1",
            port=getattr(args, "port", 8000),
            proxy_headers=False,
            access_log=False,
            limit_concurrency=32,
        )


if __name__ == "__main__":
    main()
