import asyncio
import hashlib
import ipaddress
import json
import socket
from collections import OrderedDict
from dataclasses import dataclass
from typing import Any

import aiohttp
from aiohttp.abc import AbstractResolver
from yarl import URL

from .models import public_ip


class SourceError(Exception):
    pass


class Missing(SourceError):
    pass


class PublicResolver(AbstractResolver):
    async def resolve(self, host, port=0, family=socket.AF_UNSPEC):
        addresses = await asyncio.get_running_loop().getaddrinfo(
            host, port, family=family, type=socket.SOCK_STREAM
        )
        if not addresses or any(not public_ip(address[0]) for _, _, _, _, address in addresses):
            raise OSError("non-public DNS answer")
        return [
            {
                "hostname": host,
                "host": addr[0],
                "port": port,
                "family": af,
                "proto": proto,
                "flags": socket.AI_NUMERICHOST,
            }
            for af, _, proto, _, addr in addresses
        ]

    async def close(self):
        pass


def checked_url(raw: str) -> URL:
    url = URL(raw)
    if (
        url.scheme not in {"https", "http"}
        or not url.host
        or url.user is not None
        or url.password is not None
    ):
        raise SourceError("unsupported URL")
    if url.port != (443 if url.scheme == "https" else 80):
        raise SourceError("unsupported port")
    try:
        address = ipaddress.ip_address(url.host)
    except ValueError:
        return url
    if not public_ip(str(address)):
        raise SourceError("non-public address")
    return url


class Runtime:
    def __init__(self, settings):
        self.cache = OrderedDict()
        self.rate = OrderedDict()
        self.parallel = asyncio.Semaphore(8)
        self.timeout = aiohttp.ClientTimeout(total=settings.timeout)

    async def __aenter__(self):
        options = {
            "timeout": self.timeout,
            "cookie_jar": aiohttp.DummyCookieJar(),
            "auto_decompress": False,
            "headers": {"Accept-Encoding": "identity"},
        }
        self.fixed = aiohttp.ClientSession(trust_env=True, **options)
        self.direct = aiohttp.ClientSession(
            connector=aiohttp.TCPConnector(resolver=PublicResolver(), use_dns_cache=False),
            trust_env=False,
            **options,
        )
        return self

    async def __aexit__(self, *args):
        await self.fixed.close()
        await self.direct.close()

    async def limit(self, user: int, seconds: int) -> bool:
        now = asyncio.get_running_loop().time()
        if self.rate.get(user, 0) > now:
            return False
        while self.rate and next(iter(self.rate.values())) <= now:
            self.rate.popitem(last=False)
        if len(self.rate) >= 10_000:
            return False
        self.rate[user] = now + seconds
        return True

    async def cached(self, key: str):
        expiry, value = self.cache.get(key, (0, None))
        if expiry > asyncio.get_running_loop().time():
            return value
        self.cache.pop(key, None)
        return None

    async def store(self, key: str, value):
        self.cache[key] = (asyncio.get_running_loop().time() + 300, value)
        self.cache.move_to_end(key)
        while len(self.cache) > 64:
            self.cache.popitem(last=False)


@dataclass
class Client:
    runtime: Runtime
    requests: int = 0
    cache_hits: int = 0

    async def request(
        self, url, *, direct=False, cache=False, method="GET", document=False, **options
    ) -> Any:
        parsed = checked_url(url)
        if not direct and parsed.scheme != "https":
            raise SourceError("provider requires HTTPS")
        key = (
            "osint:cache:"
            + hashlib.sha256(str(parsed.with_query(options.get("params", {}))).encode()).hexdigest()
            if cache
            else None
        )
        if key:
            hit = await self.runtime.cached(key)
            if hit is not None:
                self.cache_hits += 1
                return hit
        session = self.runtime.direct if direct else self.runtime.fixed
        async with self.runtime.parallel:
            self.requests += 1
            async with session.request(method, parsed, allow_redirects=False, **options) as response:
                if response.status == 404 and not document:
                    raise Missing("HTTP 404")
                if not document and response.status != 200:
                    raise SourceError(f"HTTP {response.status}")
                maximum = 96_000 if document else 2_000_000
                body = bytearray()
                async for chunk in response.content.iter_chunked(16384):
                    body.extend(chunk)
                    if document and len(body) >= maximum:
                        break
                    if len(body) > maximum:
                        raise SourceError("response too large")
                if document:
                    return response.status, response.headers, bytes(body[:maximum])
                try:
                    value = json.loads(body)
                except (ValueError, RecursionError) as exc:
                    raise SourceError("invalid JSON") from exc
        if key and len(body) < 256_000:
            await self.runtime.store(key, value)
        return value
