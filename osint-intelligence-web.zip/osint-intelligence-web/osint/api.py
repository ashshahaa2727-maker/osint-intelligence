import asyncio
import base64
import hashlib
import re
import secrets
import sqlite3
import time
from contextlib import asynccontextmanager
from pathlib import Path
from urllib.parse import urlencode, urlsplit

import aiohttp
import jwt
import phonenumbers
from fastapi import Depends, FastAPI, HTTPException, Request
from fastapi.responses import FileResponse, JSONResponse, RedirectResponse, Response
from fastapi.staticfiles import StaticFiles
from pydantic import BaseModel, Field, ValidationError
from starlette.middleware.trustedhost import TrustedHostMiddleware

from .db import Store, digest
from .engine import Engine
from .export import export
from .http import Client, Runtime, SourceError
from .models import Kind, Settings, Target, parse

WEB = Path(__file__).parent / "web"
COOKIE = "osint_session"
ISSUER = "https://oauth.telegram.org"
PUBLIC_MODES = {Kind.DOMAIN, Kind.WEBSITE, Kind.IP, Kind.HASH, Kind.EMAIL, Kind.COMPANY}


class Credentials(BaseModel):
    username: str = Field(min_length=3, max_length=32)
    password: str = Field(min_length=12, max_length=128)


class Search(BaseModel):
    mode: str = Field(default="auto", max_length=16)
    value: str = Field(max_length=512)
    ai: bool = False


class Toggle(BaseModel):
    enabled: bool


async def read_body(request, maximum):
    buffer = bytearray()
    async for chunk in request.stream():
        if len(buffer) + len(chunk) > maximum:
            raise HTTPException(413, "Превышен лимит размера")
        buffer.extend(chunk)
    return bytes(buffer)


async def parse_body(request, model):
    try:
        return model.model_validate_json(await read_body(request, 8192))
    except ValidationError as exc:
        raise HTTPException(422, "Проверьте введённые данные") from exc


class Jobs:
    def __init__(self, settings, store):
        self.settings = settings
        self.store = store
        self.records = {}
        self.active = {}

    def cleanup(self):
        expiry = time.monotonic() - 900
        for identifier, job in list(self.records.items()):
            if job["status"] != "running" and job["time"] <= expiry:
                self.records.pop(identifier)

    async def start(self, owner, target, ai=False):
        self.cleanup()
        if owner in self.active or len(self.active) >= self.settings.max_jobs or len(self.records) >= 128:
            raise HTTPException(429, "Слишком много заданий. Повторите позже.")
        if not await self.engine.runtime.limit(owner, self.settings.rate_seconds):
            raise HTTPException(429, "Подождите перед следующим исследованием.")
        identifier = secrets.token_hex(16)
        job = {"owner": owner, "status": "running", "modules": [], "total": 0, "time": time.monotonic()}
        self.records[identifier] = job

        async def progress(result, done, total):
            job["modules"].append({"name": result.module, "status": result.status})
            job["total"] = total

        async def run():
            try:
                report = await self.engine.investigate(target, use_ai=ai, progress=progress)
                self.store.save(owner, report)
                job.update(status="done", report=report.id)
            except asyncio.CancelledError:
                job["status"] = "cancelled"
                raise
            except (sqlite3.Error, ValueError, OSError):
                job["status"] = "failed"

        task = self.active[owner] = asyncio.create_task(run())

        def finish(completed):
            self.active.pop(owner, None)
            if completed.cancelled():
                job["status"] = "cancelled"
            elif completed.exception() is not None:
                job["status"] = "failed"
            job["time"] = time.monotonic()

        task.add_done_callback(finish)
        return identifier

    def get(self, owner, identifier):
        self.cleanup()
        item = self.records.get(identifier)
        if not item or item["owner"] != owner:
            raise HTTPException(404, "Задание не найдено")
        return item

    def cancel(self, owner):
        if task := self.active.get(owner):
            task.cancel()

    async def close(self):
        running = list(self.active.values())
        for task in running:
            task.cancel()
        await asyncio.gather(*running, return_exceptions=True)


def create_app(settings=None):
    settings = settings or Settings()
    origin = settings.web_origin.rstrip("/")
    parsed = urlsplit(origin)
    if (
        not parsed.hostname
        or parsed.username
        or parsed.path
        or parsed.query
        or parsed.fragment
        or (
            parsed.scheme != "https"
            and not (parsed.scheme == "http" and parsed.hostname in {"localhost", "127.0.0.1"})
        )
    ):
        raise ValueError("WEB_ORIGIN должен быть HTTPS либо HTTP на loopback")
    secure = parsed.scheme == "https"
    store = Store(settings.database_path, settings.retention_days)
    jobs = Jobs(settings, store)
    login_attempts = []
    password_slots = asyncio.Semaphore(2)
    github_codes = {}
    telegram_states = {}
    cookie_options = dict(httponly=True, samesite="lax", secure=secure, path="/")
    telegram_enabled = bool(
        secure
        and settings.telegram_client_id
        and settings.telegram_client_secret
        and jwt.algorithms.has_crypto
    )

    @asynccontextmanager
    async def lifespan(app):
        async with Runtime(settings) as runtime:
            jobs.engine = Engine(settings, runtime)

            async def purge():
                while True:
                    try:
                        store.purge()
                    except sqlite3.Error:
                        pass
                    for pending in (github_codes, telegram_states):
                        for key, entry in list(pending.items()):
                            if entry[0] <= time.monotonic():
                                pending.pop(key, None)
                    await asyncio.sleep(300)

            maintenance = asyncio.create_task(purge())
            try:
                yield
            finally:
                await jobs.close()
                maintenance.cancel()
                await asyncio.gather(maintenance, return_exceptions=True)

    app = FastAPI(lifespan=lifespan, docs_url=None, redoc_url=None, openapi_url=None)
    app.add_middleware(TrustedHostMiddleware, allowed_hosts=[parsed.hostname])

    @app.middleware("http")
    async def protect(request, call_next):
        if request.method not in {"GET", "HEAD"} and (
            request.headers.get("x-osint") != "1"
            or request.headers.get("origin", origin) != origin
            or request.headers.get("sec-fetch-site") == "cross-site"
        ):
            return JSONResponse({"detail": "Запрос отклонён"}, 403)
        response = await call_next(request)
        response.headers.update(
            {
                "Cache-Control": "no-store",
                "Content-Security-Policy": "default-src 'none'; style-src 'self'; script-src 'self'; "
                "img-src 'self'; connect-src 'self'; frame-ancestors 'none'; base-uri 'none'; form-action 'self'",
                "X-Content-Type-Options": "nosniff",
                "Referrer-Policy": "no-referrer",
                "Permissions-Policy": "camera=(), microphone=(), geolocation=()",
            }
        )
        return response

    def current(request: Request):
        user = store.session(request.cookies.get(COOKIE, ""))
        if user is None:
            raise HTTPException(401, "Войдите в аккаунт")
        return user

    def administrator(user=Depends(current)):
        if not user["admin"]:
            raise HTTPException(403, "Требуются права администратора")
        return user

    def checked_report(user, identifier):
        report = store.get(user["id"], identifier)
        if not report:
            raise HTTPException(404, "Отчёт не найден")
        return report

    @app.get("/")
    async def index():
        return FileResponse(WEB / "index.html")

    app.mount("/assets", StaticFiles(directory=WEB), name="assets")

    @app.post("/api/login")
    async def login(request: Request):
        now = time.monotonic()
        login_attempts[:] = [stamp for stamp in login_attempts if now - stamp < 60]
        if len(login_attempts) >= 15:
            raise HTTPException(429, "Слишком много попыток входа")
        credentials = await parse_body(request, Credentials)
        if len(login_attempts) >= 15:
            raise HTTPException(429, "Слишком много попыток входа")
        login_attempts.append(now)
        async with password_slots:
            token = await asyncio.to_thread(store.login, credentials.username, credentials.password)
        if not token:
            raise HTTPException(401, "Неверное имя или пароль")
        if previous := request.cookies.get(COOKIE):
            store.logout(previous)
        response = JSONResponse({"ok": True})
        response.set_cookie(COOKIE, token, max_age=43200, **cookie_options)
        return response

    @app.post("/api/logout")
    async def logout(request: Request, user=Depends(current)):
        token = request.cookies[COOKIE]
        store.logout(token)
        telegram_states.pop(digest(token), None)
        github_codes.pop(digest(token), None)
        response = Response(status_code=204)
        response.delete_cookie(COOKIE, **cookie_options)
        return response

    @app.get("/api/me")
    async def me(user=Depends(current)):
        return {
            "username": user["username"],
            "admin": bool(user["admin"]),
            "telegram": telegram_enabled,
            "ai": bool(settings.openai_key),
            "file_bytes": settings.file_bytes,
            "retention": settings.retention_days,
        }

    @app.post("/api/github")
    async def github_challenge(request: Request, user=Depends(current)):
        challenge = "osint-" + secrets.token_hex(12)
        session = digest(request.cookies[COOKIE])
        if session not in github_codes and len(github_codes) >= 128:
            raise HTTPException(429, "Повторите позже")
        github_codes[session] = (time.monotonic() + 600, challenge)
        return {"challenge": challenge}

    @app.post("/api/studies", status_code=202)
    async def lookup(request: Request, user=Depends(current)):
        form = await parse_body(request, Search)
        session = digest(request.cookies[COOKIE])
        try:
            if form.mode == Kind.USERNAME:
                expiry, challenge = github_codes.get(session, (0, ""))
                username = form.value.strip().removeprefix("@")
                if expiry <= time.monotonic() or not re.fullmatch(
                    r"[A-Za-z0-9](?:[A-Za-z0-9-]{0,37}[A-Za-z0-9])?", username
                ):
                    raise ValueError("github")
                target = Target(
                    kind=Kind.USERNAME,
                    value=username,
                    subject="GitHub",
                    authorization="github-challenge",
                    profile={"challenge": challenge},
                )
            else:
                mode = None if form.mode == "auto" else Kind(form.mode)
                if mode is not None and mode not in PUBLIC_MODES:
                    raise ValueError("mode")
                target = parse(form.value, mode)
                if target.kind not in PUBLIC_MODES:
                    raise ValueError("mode")
        except ValueError as exc:
            raise HTTPException(422, "Проверьте запрос и подтверждение владения") from exc
        identifier = await jobs.start(user["id"], target, form.ai)
        if form.mode == Kind.USERNAME:
            github_codes.pop(session, None)
        return {"job": identifier}

    @app.post("/api/upload/{kind}", status_code=202)
    async def upload(kind: str, request: Request, user=Depends(current)):
        if (
            kind not in {Kind.FILE, Kind.IMAGE}
            or request.headers.get("content-type") != "application/octet-stream"
        ):
            raise HTTPException(415, "Выберите файл или изображение")
        payload = await read_body(request, settings.file_bytes)
        if not payload:
            raise HTTPException(422, "Пустой файл")
        target = Target(kind=kind, value="", subject="Вложение", payload=payload, authorization="web-upload")
        return {"job": await jobs.start(user["id"], target)}

    @app.post("/api/telegram/{kind}")
    async def telegram_start(kind: str, request: Request, user=Depends(current)):
        if not telegram_enabled or kind not in {Kind.TELEGRAM, Kind.PHONE}:
            raise HTTPException(404, "Интеграция Telegram недоступна")
        state, verifier = secrets.token_urlsafe(32), secrets.token_urlsafe(48)
        session = digest(request.cookies[COOKIE])
        if session not in telegram_states and len(telegram_states) >= 128:
            raise HTTPException(429, "Повторите позже")
        telegram_states[session] = (time.monotonic() + 600, state, verifier, kind)
        challenge = base64.urlsafe_b64encode(hashlib.sha256(verifier.encode()).digest()).decode().rstrip("=")
        query = urlencode(
            {
                "client_id": settings.telegram_client_id,
                "redirect_uri": origin + "/auth/telegram",
                "response_type": "code",
                "scope": "openid profile" if kind == Kind.TELEGRAM else "openid phone",
                "state": state,
                "code_challenge": challenge,
                "code_challenge_method": "S256",
            }
        )
        return {"url": f"{ISSUER}/auth?{query}"}

    @app.get("/auth/telegram")
    async def telegram_callback(request: Request, state: str = "", code: str = ""):
        token = request.cookies.get(COOKIE, "")
        user = store.session(token)
        if not user or not telegram_enabled or not code or len(code) > 2048:
            return RedirectResponse("/#telegram-error", status_code=303)
        session = digest(token)
        pending = telegram_states.get(session)
        if not pending or pending[0] <= time.monotonic() or not secrets.compare_digest(pending[1], state):
            return RedirectResponse("/#telegram-error", status_code=303)
        telegram_states.pop(session, None)
        try:
            client = Client(jobs.engine.runtime)
            data = await client.request(
                ISSUER + "/token",
                method="POST",
                headers={
                    "Authorization": "Basic "
                    + base64.b64encode(
                        (
                            settings.telegram_client_id
                            + ":"
                            + settings.telegram_client_secret.get_secret_value()
                        ).encode()
                    ).decode("ascii")
                },
                data={
                    "grant_type": "authorization_code",
                    "code": code,
                    "redirect_uri": origin + "/auth/telegram",
                    "client_id": settings.telegram_client_id,
                    "code_verifier": pending[2],
                },
            )
            id_token = data["id_token"]
            keys = await client.request(ISSUER + "/.well-known/jwks.json", cache=True)
            header = jwt.get_unverified_header(id_token)
            if header.get("alg") != "RS256":
                raise ValueError("unexpected JWT algorithm")
            jwk = next(
                item for item in keys["keys"] if item.get("kid") == header.get("kid") and item["kty"] == "RSA"
            )
            claims = jwt.decode(
                id_token,
                jwt.PyJWK.from_dict(jwk, "RS256").key,
                algorithms=["RS256"],
                issuer=ISSUER,
                audience=settings.telegram_client_id,
                options={"require": ["sub", "iat", "exp", "iss", "aud"]},
            )
            if pending[3] == Kind.PHONE:
                number = claims["phone_number"]
                if claims.get("phone_number_verified") is not True or not re.fullmatch(
                    r"\+?[1-9][0-9]{6,14}", number
                ):
                    raise ValueError("phone not verified")
                value = "+" + number.lstrip("+")
                phonenumbers.parse(value, None)
                target = Target(
                    kind=Kind.PHONE, value=value, subject="•••" + value[-3:], authorization="telegram-oidc"
                )
            else:
                profile = {key: claims[key] for key in ("id", "preferred_username") if key in claims}
                target = Target(
                    kind=Kind.TELEGRAM,
                    value="",
                    subject="Telegram",
                    profile=profile,
                    authorization="telegram-oidc",
                )
            identifier = await jobs.start(user["id"], target)
        except (
            KeyError,
            ValueError,
            TypeError,
            StopIteration,
            jwt.PyJWTError,
            SourceError,
            aiohttp.ClientError,
            TimeoutError,
            HTTPException,
            phonenumbers.NumberParseException,
        ):
            return RedirectResponse("/#telegram-error", status_code=303)
        return RedirectResponse("/#job=" + identifier, status_code=303)

    @app.get("/api/jobs/{identifier}")
    async def job(identifier: str, user=Depends(current)):
        item = jobs.get(user["id"], identifier)
        return {key: value for key, value in item.items() if key not in {"owner", "time"}}

    @app.delete("/api/jobs/{identifier}", status_code=204)
    async def cancel(identifier: str, user=Depends(current)):
        item = jobs.get(user["id"], identifier)
        if item["status"] == "running":
            jobs.cancel(user["id"])
        return Response(status_code=204)

    @app.get("/api/studies")
    async def history(kind: str = "", q: str = "", user=Depends(current)):
        return store.list(user["id"], kind[:20], q[:120])

    @app.get("/api/studies/{identifier}")
    async def report(identifier: str, user=Depends(current)):
        return checked_report(user, identifier)

    @app.delete("/api/studies/{identifier}", status_code=204)
    async def remove(identifier: str, user=Depends(current)):
        if not store.delete(user["id"], identifier):
            raise HTTPException(404, "Отчёт не найден")
        return Response(status_code=204)

    @app.get("/api/studies/{identifier}/export/{fmt}")
    async def download(identifier: str, fmt: str, user=Depends(current)):
        media = {"json": "application/json", "html": "text/html", "pdf": "application/pdf"}
        if fmt not in media:
            raise HTTPException(404, "Формат недоступен")
        report = checked_report(user, identifier)
        if fmt == "pdf":
            async with password_slots:
                result = await asyncio.to_thread(export, report, fmt, "ru")
        else:
            result = export(report, fmt, "ru")
        return Response(
            result,
            media_type=media[fmt],
            headers={"Content-Disposition": f'attachment; filename="osint-{report.id}.{fmt}"'},
        )

    @app.get("/api/admin")
    async def admin_panel(user=Depends(administrator)):
        return {
            "accounts": store.accounts(),
            "active": len(jobs.active),
            "providers": {
                name.removesuffix("_key"): bool(getattr(settings, name))
                for name in Settings.model_fields
                if name.endswith("_key")
            },
        }

    @app.post("/api/admin/accounts", status_code=201)
    async def create_account(request: Request, user=Depends(administrator)):
        form = await parse_body(request, Credentials)
        try:
            async with password_slots:
                await asyncio.to_thread(store.create, form.username, form.password)
        except (ValueError, sqlite3.IntegrityError) as exc:
            raise HTTPException(409, "Имя занято или не соответствует формату") from exc
        return {"ok": True}

    @app.patch("/api/admin/accounts/{identifier}")
    async def set_account(identifier: int, request: Request, user=Depends(administrator)):
        form = await parse_body(request, Toggle)
        if not store.enable(identifier, form.enabled):
            raise HTTPException(404, "Доступный для управления аккаунт не найден")
        if not form.enabled:
            jobs.cancel(identifier)
        return {"ok": True}

    return app
