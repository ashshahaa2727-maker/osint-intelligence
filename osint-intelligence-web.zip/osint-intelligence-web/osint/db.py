import hashlib
import re
import secrets
import sqlite3
import time
from contextlib import contextmanager
from pathlib import Path

from .models import Report

SCHEMA = """
CREATE TABLE IF NOT EXISTS accounts (
    id INTEGER PRIMARY KEY, username TEXT UNIQUE NOT NULL, password TEXT NOT NULL,
    admin INTEGER NOT NULL DEFAULT 0, enabled INTEGER NOT NULL DEFAULT 1
);
CREATE TABLE IF NOT EXISTS web_sessions (
    digest TEXT PRIMARY KEY, owner INTEGER NOT NULL REFERENCES accounts(id) ON DELETE CASCADE,
    expires INTEGER NOT NULL
);
CREATE TABLE IF NOT EXISTS studies (
    id TEXT PRIMARY KEY, owner INTEGER NOT NULL REFERENCES accounts(id) ON DELETE CASCADE,
    created TEXT NOT NULL, expires INTEGER NOT NULL, kind TEXT NOT NULL, subject TEXT NOT NULL, body TEXT NOT NULL
);
CREATE INDEX IF NOT EXISTS studies_owner ON studies(owner, created DESC);
CREATE INDEX IF NOT EXISTS studies_expires ON studies(expires);
"""


def password_hash(password, salt=None):
    salt = salt or secrets.token_hex(16)
    result = hashlib.scrypt(
        password.encode(), salt=bytes.fromhex(salt), n=2**15, r=8, p=1, maxmem=64 * 1024**2
    )
    return f"{salt}:{result.hex()}"


def digest(token):
    return hashlib.sha256(token.encode()).hexdigest()


class Store:
    def __init__(self, path, days):
        self.path = Path(path).expanduser()
        self.days = days
        self.path.parent.mkdir(mode=0o700, parents=True, exist_ok=True)
        self.path.touch(mode=0o600, exist_ok=True)
        with self.connection() as db:
            db.execute("PRAGMA journal_mode=WAL")
            db.executescript(SCHEMA)
        self.dummy = password_hash("invalid-account")

    @contextmanager
    def connection(self):
        db = sqlite3.connect(self.path, timeout=2)
        db.row_factory = sqlite3.Row
        db.execute("PRAGMA foreign_keys=ON")
        db.execute("PRAGMA secure_delete=ON")
        try:
            with db:
                yield db
        finally:
            db.close()

    def create(self, username, password, admin=False):
        username = username.lower()
        if not re.fullmatch("[a-z0-9][a-z0-9_-]{2,31}", username) or not 12 <= len(password) <= 128:
            raise ValueError("Имя: 3–32 символа (a–z, 0–9, _ и -). Пароль: 12–128 символов.")
        hashed = password_hash(password)
        with self.connection() as db:
            db.execute(
                "INSERT INTO accounts(username,password,admin) VALUES(?,?,?)", (username, hashed, admin)
            )

    def login(self, username, password):
        with self.connection() as db:
            account = db.execute("SELECT * FROM accounts WHERE username=?", (username.lower(),)).fetchone()
        saved = account["password"] if account else self.dummy
        computed = password_hash(password, saved.split(":")[0])
        if not secrets.compare_digest(saved, computed) or not account or not account["enabled"]:
            return None
        token = secrets.token_urlsafe(32)
        with self.connection() as db:
            db.execute(
                "INSERT INTO web_sessions VALUES(?,?,?)",
                (digest(token), account["id"], int(time.time()) + 43200),
            )
        return token

    def session(self, token):
        if not token or len(token) != 43:
            return None
        with self.connection() as db:
            return db.execute(
                """SELECT accounts.id,username,admin FROM accounts JOIN web_sessions
                ON accounts.id=web_sessions.owner WHERE digest=? AND expires>? AND enabled=1""",
                (digest(token), time.time()),
            ).fetchone()

    def logout(self, token):
        with self.connection() as db:
            db.execute("DELETE FROM web_sessions WHERE digest=?", (digest(token),))

    def save(self, owner, report):
        with self.connection() as db:
            db.execute(
                "INSERT INTO studies VALUES(?,?,?,?,?,?,?)",
                (
                    report.id,
                    owner,
                    report.created.isoformat(),
                    int(time.time()) + self.days * 86400,
                    report.kind,
                    report.subject,
                    report.model_dump_json(),
                ),
            )

    def list(self, owner, kind, query):
        with self.connection() as db:
            rows = db.execute(
                """SELECT id,created,kind,subject FROM studies WHERE owner=? AND expires>?
                AND (?='' OR kind=?) AND (?='' OR instr(lower(subject),lower(?))>0 OR id=?)
                ORDER BY created DESC LIMIT 100""",
                (owner, time.time(), kind, kind, query, query, query),
            )
            return [dict(row) for row in rows]

    def get(self, owner, identifier):
        with self.connection() as db:
            row = db.execute(
                "SELECT body FROM studies WHERE owner=? AND id=? AND expires>?",
                (owner, identifier, time.time()),
            ).fetchone()
        return Report.model_validate_json(row["body"]) if row else None

    def delete(self, owner, identifier):
        with self.connection() as db:
            return db.execute("DELETE FROM studies WHERE owner=? AND id=?", (owner, identifier)).rowcount

    def purge(self):
        with self.connection() as db:
            db.execute("DELETE FROM studies WHERE expires<=?", (time.time(),))
            db.execute("DELETE FROM web_sessions WHERE expires<=?", (time.time(),))

    def accounts(self):
        with self.connection() as db:
            rows = db.execute("SELECT id,username,admin,enabled FROM accounts ORDER BY username LIMIT 200")
            return [dict(row) for row in rows]

    def enable(self, identifier, enabled):
        with self.connection() as db:
            result = db.execute("UPDATE accounts SET enabled=? WHERE id=? AND admin=0", (enabled, identifier))
            if not enabled:
                db.execute(
                    "DELETE FROM web_sessions WHERE owner=? AND EXISTS "
                    "(SELECT 1 FROM accounts WHERE id=? AND admin=0)",
                    (identifier, identifier),
                )
            return result.rowcount
