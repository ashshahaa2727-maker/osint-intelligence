import asyncio
import io
import time
from urllib.parse import parse_qs, urlsplit

import pytest
from fastapi.testclient import TestClient
from PIL import Image

from osint.api import create_app
from osint.db import Store
from osint.engine import Engine
from osint.http import Runtime, SourceError, checked_url
from osint.models import Kind, Settings, Target, parse

PASSWORD = "test-only-password"
WRITE = {"X-OSINT": "1"}


@pytest.fixture
def app_settings(tmp_path):
    settings = Settings(
        _env_file=None,
        database_path=str(tmp_path / "test.sqlite"),
        rate_seconds=1,
        file_bytes=1024,
        openai_key="key-never-shown",
    )
    store = Store(settings.database_path, 7)
    store.create("alice", PASSWORD, admin=True)
    store.create("bob", PASSWORD)
    return settings


def login(client, name):
    return client.post("/api/login", json={"username": name, "password": PASSWORD}, headers=WRITE)


def completed(client, job):
    for _ in range(50):
        response = client.get("/api/jobs/" + job)
        assert response.status_code == 200
        body = response.json()
        if body["status"] != "running":
            return body
        time.sleep(0.04)
    pytest.fail("job remained running")


def test_authorization_and_accounts(app_settings):
    with TestClient(create_app(app_settings), base_url=app_settings.web_origin) as client:
        assert client.get("/").status_code == 200
        assert client.get("/assets/app.js").status_code == 200
        assert client.get("/api/studies").status_code == 401
        assert client.post("/api/login").status_code == 403
        assert (
            client.post("/api/login", headers={**WRITE, "Origin": "https://unknown.example"}).status_code
            == 403
        )
        assert client.get("/", headers={"Host": "unknown.example"}).status_code == 400
        assert login(client, "wrong").status_code == 401
        response = login(client, "alice")
        assert response.status_code == 200 and "HttpOnly" in response.headers["set-cookie"]
        admin = client.get("/api/admin")
        assert admin.status_code == 200
        assert "key-never-shown" not in admin.text and "password" not in admin.text
        assert admin.json()["providers"]["openai"]
        result = client.post(
            "/api/admin/accounts", headers=WRITE, json={"username": "carol", "password": PASSWORD}
        )
        assert result.status_code == 201
        cookie = client.cookies.get("osint_session")
        assert client.post("/api/logout", headers=WRITE).status_code == 204
        assert client.get("/api/admin", headers={"cookie": "osint_session=" + cookie}).status_code == 401
        assert login(client, "carol").status_code == 200
        assert client.get("/api/admin").status_code == 403
        carol_token = client.cookies.get("osint_session")
        assert login(client, "alice").status_code == 200
        identifier = next(
            item["id"] for item in client.get("/api/admin").json()["accounts"] if item["username"] == "carol"
        )
        assert (
            client.patch(
                f"/api/admin/accounts/{identifier}", headers=WRITE, json={"enabled": False}
            ).status_code
            == 200
        )
        client.cookies.clear()
        assert client.get("/api/me", headers={"cookie": "osint_session=" + carol_token}).status_code == 401
        assert login(client, "carol").status_code == 401


def test_upload_study_report_isolation_exports_delete(app_settings):
    with TestClient(create_app(app_settings), base_url=app_settings.web_origin) as client:
        login(client, "alice")
        binary = {**WRITE, "Content-Type": "application/octet-stream"}
        assert client.post("/api/upload/file", content=b"x" * 1025, headers=binary).status_code == 413
        buffer = io.BytesIO()
        Image.new("RGB", (3, 4)).save(buffer, "PNG")
        response = client.post("/api/upload/image", content=buffer.getvalue(), headers=binary)
        assert response.status_code == 202
        job = response.json()["job"]
        result = completed(client, job)
        assert result["status"] == "done"
        identifier = result["report"]
        report = client.get(f"/api/studies/{identifier}").json()
        assert report["summary"]["facts"] >= 5
        assert any(f["key"] == "image.width" and f["value"] == 3 for f in report["findings"])
        assert len(client.get("/api/studies?kind=image").json()) == 1
        assert client.get("/api/studies?kind=phone").json() == []
        for fmt, prefix in [("pdf", b"%PDF"), ("html", b"<!doctype html>"), ("json", b"{")]:
            response = client.get(f"/api/studies/{identifier}/export/{fmt}")
            assert response.content.startswith(prefix)
            assert response.headers["content-disposition"].startswith("attachment")
        login(client, "bob")
        assert client.get(f"/api/jobs/{job}").status_code == 404
        assert client.get(f"/api/studies/{identifier}").status_code == 404
        assert client.get(f"/api/studies/{identifier}/export/pdf").status_code == 404
        assert client.delete(f"/api/studies/{identifier}", headers=WRITE).status_code == 404
        login(client, "alice")
        assert client.delete(f"/api/studies/{identifier}", headers=WRITE).status_code == 204
        assert client.get("/api/studies").json() == []


def test_owner_challenge_and_minimization(app_settings, monkeypatch):
    from osint.http import Client

    code = None

    async def fetch(self, url, **options):
        assert url == "https://api.github.com/users/test-account"
        return {"bio": "control " + code, "login": "test-account"}

    monkeypatch.setattr(Client, "request", fetch)
    with TestClient(create_app(app_settings), base_url=app_settings.web_origin) as client:
        login(client, "alice")
        assert (
            client.post(
                "/api/studies", json={"mode": "phone", "value": "+12025550127"}, headers=WRITE
            ).status_code
            == 422
        )
        payload = {"mode": "username", "value": "test-account"}
        assert client.post("/api/studies", json=payload, headers=WRITE).status_code == 422
        code = client.post("/api/github", headers=WRITE).json()["challenge"]
        response = client.post("/api/studies", json=payload, headers=WRITE)
        result = completed(client, response.json()["job"])
        saved = client.get("/api/studies/" + result["report"])
        assert "test-account" in saved.text and code not in saved.text
        assert client.post("/api/studies", json=payload, headers=WRITE).status_code == 422
        email = parse("somebody@example.com", Kind.EMAIL)
        assert email.subject == email.value == "example.com"


def test_telegram_state_and_pkce(app_settings):
    settings = app_settings.model_copy(
        update={"web_origin": "https://audit.example", "telegram_client_id": "1234"}
    )
    settings = Settings(
        _env_file=None, **(settings.model_dump() | {"telegram_client_secret": "example-only"})
    )
    with TestClient(create_app(settings), base_url=settings.web_origin) as client:
        assert "Secure" in login(client, "alice").headers["set-cookie"]
        response = client.post("/api/telegram/phone", headers=WRITE)
        assert response.status_code == 200
        query = parse_qs(urlsplit(response.json()["url"]).query)
        assert query["scope"] == ["openid phone"] and query["code_challenge_method"] == ["S256"]
        invalid = client.get("/auth/telegram?state=wrong&code=bad", follow_redirects=False)
        assert invalid.headers["location"] == "/#telegram-error"


@pytest.mark.parametrize(
    "target",
    [
        "127.0.0.1",
        "100.64.0.1",
        "::ffff:8.8.8.8",
        "http://127.0.0.1",
        "https://user@host.net",
        "https://example.com:444",
        "@someone",
    ],
)
def test_invalid_target(target):
    with pytest.raises(ValueError):
        parse(target)


@pytest.mark.parametrize(
    "address", ["http://169.254.169.254/", "http://[64:ff9b::a00:1]/", "file:///etc/passwd"]
)
def test_network_guard(address):
    with pytest.raises(SourceError):
        checked_url(address)


async def test_engine_ownership_and_cancel(app_settings):
    async with Runtime(app_settings) as runtime:
        engine = Engine(app_settings, runtime)
        with pytest.raises(ValueError):
            await engine.investigate(Target(kind=Kind.PHONE, subject="phone", value="+12025550123"))
        enabled = asyncio.Event()

        async def pause(result, done, total):
            enabled.set()
            await asyncio.sleep(60)

        target = Target(
            kind=Kind.FILE, subject="file", value="", payload=b"plain", authorization="web-upload"
        )
        task = asyncio.create_task(engine.investigate(target, progress=pause))
        await asyncio.wait_for(enabled.wait(), 2)
        task.cancel()
        with pytest.raises(asyncio.CancelledError):
            await task


def test_telegram_verified_phone(app_settings, monkeypatch):
    import jwt
    from cryptography.hazmat.primitives.asymmetric import rsa

    from osint.http import Client

    private = rsa.generate_private_key(public_exponent=65537, key_size=2048)
    key = jwt.algorithms.RSAAlgorithm.to_jwk(private.public_key(), as_dict=True)
    key["kid"] = "test"
    now = int(time.time())
    claims = {
        "iss": "https://oauth.telegram.org",
        "aud": "1234",
        "sub": "123",
        "iat": now,
        "exp": now + 60,
        "phone_number": "12025550123",
        "phone_number_verified": True,
    }

    async def request(self, url, **kwargs):
        if url.endswith("/token"):
            assert kwargs.get("method") == "POST" and kwargs["data"]["code_verifier"]
            return {"id_token": jwt.encode(claims, private, "RS256", headers={"kid": "test"})}
        assert url == "https://oauth.telegram.org/.well-known/jwks.json"
        return {"keys": [key]}

    monkeypatch.setattr(Client, "request", request)
    settings = Settings(
        _env_file=None,
        **(
            app_settings.model_dump()
            | {
                "web_origin": "https://audit.example",
                "telegram_client_id": "1234",
                "telegram_client_secret": "example",
            }
        ),
    )
    with TestClient(create_app(settings), base_url=settings.web_origin) as client:
        login(client, "alice")
        url = client.post("/api/telegram/phone", headers=WRITE).json()["url"]
        state = parse_qs(urlsplit(url).query)["state"][0]
        callback = client.get(
            "/auth/telegram", params={"state": state, "code": "code"}, follow_redirects=False
        )
        job = callback.headers["location"].removeprefix("/#job=")
        assert len(job) == 32
        report_id = completed(client, job)["report"]
        report = client.get("/api/studies/" + report_id)
        assert report.json()["kind"] == "phone" and "12025550123" not in report.text
        replay = client.get("/auth/telegram", params={"state": state, "code": "code"}, follow_redirects=False)
        assert replay.headers["location"] == "/#telegram-error"
        claims["aud"] = "other"
        url = client.post("/api/telegram/phone", headers=WRITE).json()["url"]
        state = parse_qs(urlsplit(url).query)["state"][0]
        invalid = client.get(
            "/auth/telegram", params={"state": state, "code": "code"}, follow_redirects=False
        )
        assert invalid.headers["location"] == "/#telegram-error"
