#!/data/data/com.termux/files/usr/bin/bash
set -euo pipefail
umask 077
cd -- "$(dirname -- "$0")"
if [[ -z "${TERMUX_VERSION:-}" || "$(uname -m)" != aarch64 ]]; then
    printf '%s\n' 'Запустите в ARM64 Termux командой: bash setup-termux.sh' >&2
    exit 1
fi
pkg update
pkg install -y python python-pip clang make rust pkg-config binutils patchelf python-pillow
python -m venv --system-site-packages .venv
export CARGO_BUILD_JOBS="${CARGO_BUILD_JOBS:-2}"
export CARGO_INCREMENTAL=0
.venv/bin/python -m pip install -r requirements.in
.venv/bin/python -c 'import aiohttp, fastapi, pydantic_core, sqlite3; from PIL import Image; import osint.api'
if [[ ! -e .env ]]; then
    cp .env.example .env
fi
chmod 600 .env
printf '%s\n' 'Следующий шаг: .venv/bin/python -m osint create-admin admin'
